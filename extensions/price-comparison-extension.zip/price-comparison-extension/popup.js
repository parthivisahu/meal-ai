document.addEventListener('DOMContentLoaded', async () => {
  const statusDiv = document.getElementById('status');

  // Get current tab
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const url = tab?.url || '';

  // Check if on supported site
  let onSupportedSite = false;
  let siteName = '';
  
  if (url.includes('blinkit.com')) {
    onSupportedSite = true;
    siteName = 'Blinkit';
  } else if (url.includes('bigbasket.com')) {
    onSupportedSite = true;
    siteName = 'BigBasket';
  } else if (url.includes('zepto.com')) {
    onSupportedSite = true;
    siteName = 'Zepto';
  } else if (url.includes('swiggy.com')) {
    onSupportedSite = true;
    siteName = 'Instamart';
  }

  // Check token
  chrome.storage.local.get(['meal_ai_token'], (result) => {
    if (result.meal_ai_token && onSupportedSite) {
      statusDiv.innerHTML = `✅ Active on ${siteName}<br><small>Capturing prices...</small>`;
      statusDiv.className = 'status active';
    } else if (result.meal_ai_token && !onSupportedSite) {
      statusDiv.innerHTML = '⚠️ Site Not Supported<br><small>Go to Blinkit, BB, Zepto, or Swiggy</small>';
      statusDiv.className = 'status inactive';
    } else {
      statusDiv.innerHTML = '❌ Not Logged In<br><small>Login at localhost:5173</small>';
      statusDiv.className = 'status inactive';
    }
  });
});
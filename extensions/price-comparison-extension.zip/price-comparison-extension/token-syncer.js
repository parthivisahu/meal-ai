(() => {
  const syncToken = () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) return;

      if (!chrome?.runtime?.id) return;

      chrome.storage.local.set({ meal_ai_token: token }, () => {
        // success
      });
    } catch (err) {
      // ignore
    }
  };

  syncToken();
  window.addEventListener('storage', (e) => {
    if (e.key === 'token') syncToken();
  });
  setInterval(syncToken, 5000);
})();

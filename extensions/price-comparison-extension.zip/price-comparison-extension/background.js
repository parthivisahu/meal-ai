const API = 'http://localhost:5000/api/price-comparison/ingest';

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'INGEST_PRICE') {
        const { token, data } = message;
        
        fetch(API, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(result => {
            // console.log('[Meal-AI Background] Success:', result);
        })
        .catch(err => {
            // console.error('[Meal-AI Background] Error:', err);
        });
    }
    return true;
});
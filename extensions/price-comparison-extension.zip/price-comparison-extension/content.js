﻿(() => {
    const sent = new Map();
    
    const getPlatform = () => {
        if (location.hostname.includes('blinkit')) return 'blinkit';
        if (location.hostname.includes('bigbasket')) return 'bigbasket';
        if (location.hostname.includes('zepto')) return 'zepto';
        if (location.hostname.includes('swiggy')) return 'instamart';
        return 'unknown';
    };

    const platform = getPlatform();
    if (platform === 'unknown') return;

    const cleanPrice = (txt) => {
        if (!txt) return 0;
        const match = txt.replace(/,/g, '').match(/([0-9]+(?:\.[0-9]+)?)/);
        return match ? Number(match[1]) : 0;
    };

    const extractPrices = (txt) => {
        if (!txt) return [];
        const matches = txt.match(/(?:\u20B9|Rs\.?\s*)\s*[0-9][0-9,]*(?:\.[0-9]{1,2})?/gi) || [];
        return matches
            .map(m => cleanPrice(m))
            .filter(v => Number.isFinite(v) && v > 0);
    };

    const isInvalidName = (text) => {
        const t = text.toUpperCase();
        const weightOnlyRegex = /^[\x00-\x7F]+(kg|g|l|ml|pcs|units|approx|x)+$/i;
        return (
            t.includes('OFF') || t.includes('SAVE') || t.includes('DISCOUNT') || 
            t.includes('MRP') || t.includes('ADD') || t.includes('APPROX') || 
            t.includes('MINS') || t.includes('DELIVERY') || t.includes('ETA') ||
            t.includes('HAR DIN SASTA') || t.includes('FRESHO') ||
            weightOnlyRegex.test(text.trim()) || t.length < 3 || !/[a-zA-Z]/.test(text)
        );
    };

    const sendToBackground = async (name, price, quantity) => {
        chrome.storage.local.get(['meal_ai_token'], (result) => {
            const token = result.meal_ai_token;
            if (!token) return; 
    
            // Relay to background script to bypass protocol security (HTTP vs HTTPS)
            chrome.runtime.sendMessage({
                type: 'INGEST_PRICE',
                token: token,
                data: { platform, name, price, quantity: quantity || '1 unit' }
            });
            
            // Minimal, clean confirmation log
            console.log(`%c🛒 Meal-AI: Captured ${name.substring(0, 20)}...`, 'color: #2e7d32; font-weight: bold');
        });
    };

    const scanHeuristic = () => {
        const walker = document.createTreeWalker(
            document.body,
            NodeFilter.SHOW_TEXT,
            {
                acceptNode: function(node) {
                    if (node.parentElement.offsetParent === null) return NodeFilter.FILTER_REJECT;
                    if (/\u20B9|Rs\.?/i.test(node.textContent)) return NodeFilter.FILTER_ACCEPT;
                    return NodeFilter.FILTER_SKIP;
                }
            }
        );

        let currentNode;
        while (currentNode = walker.nextNode()) {
            const price = cleanPrice(currentNode.textContent);
            if (!price || price < 5 || price > 10000) continue;

            let container = currentNode.parentElement;
            let nameFound = null;
            let quantityFound = '1 unit';
            let minPrice = price;

            for (let i = 0; i < 5; i++) {
                if (!container) break;
                
                const headerName = container.querySelector('h2, h3, h4, h5, a[href*="/pd/"], [data-testid="product-name"], [data-testid="item-name"]');
                if (headerName && headerName.innerText.length > 3 && !isInvalidName(headerName.innerText)) {
                     nameFound = headerName.innerText;
                }

                if (!nameFound) {
                    const texts = container.innerText.split('\n').filter(t => t.trim().length > 3);
                    const candidates = texts.filter(t => !/\u20B9|Rs\.?/i.test(t) && !t.match(/^\d+$/) && !isInvalidName(t));
                    if (candidates.length > 0) {
                        nameFound = candidates.sort((a, b) => b.length - a.length)[0];
                    }
                }

                if (nameFound) {
                    const qtyMatch = container.innerText.match(/(\d+(\.\d+)?\s*(kg|g|l|ml|pcs|units))/i);
                    if (qtyMatch) quantityFound = qtyMatch[0];
                    const pricesInContainer = extractPrices(container.innerText);
                    if (pricesInContainer.length > 0) {
                        const candidateMin = Math.min(...pricesInContainer);
                        if (candidateMin > 0) minPrice = candidateMin;
                    }
                    break;
                }
                container = container.parentElement;
            }

            if (nameFound && nameFound.length < 150) {
                const normalizedName = nameFound.trim();
                const prev = sent.get(normalizedName);
                if (prev === undefined || minPrice < prev) {
                    sent.set(normalizedName, minPrice);
                    sendToBackground(normalizedName, minPrice, quantityFound);
                }
            }
        }
    };

    setInterval(scanHeuristic, 2000);
})();
